
graph = {
    "A": [("B", 2), ("C", 4)],
    "B": [("D", 2), ("E", 3)],
    "C": [("F", 1)],
    "D": [],
    "E": [],
    "F": [("G", 3)],
    "G": []
}

# Heuristic values
h = {
    "A": 8,
    "B": 0,
    "C": 4,
    "D": 0,
    "E": 0,
    "F": 3,
    "G": 0
}

visited = []
stack = []

def astar(node):
    stack.append((h[node], 0, node))

    while stack:
        stack.sort()
        f, cost, temp = stack.pop(0)

        if temp not in visited:
            print(temp, "g:", cost, "h:", h[temp], "f:", f)
            visited.append(temp)

            if temp == "G":
                print("Goal Reached!")
                break

            for child, c in graph[temp]:
                new_cost = cost + c
                new_f = new_cost + h[child]
                stack.append((new_f, new_cost, child))

astar("A")
