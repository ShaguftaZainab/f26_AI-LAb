
graph = {
    "A": [("B", 2), ("C", 4)],
    "B": [("D", 2), ("E", 3                                                                                                                                                                                                 )],
    "C": [("F", 1)],
    "D": [],
    "E": [],
    "F": [("G", 3)],
    "G": []
}

visited = []
stack = []

def ucs(node):
    stack.append((0, node))

    while stack:
        stack.sort()
        cost, temp = stack.pop(0)

        if temp not in visited:
            print(temp, "Cost:", cost)
            visited.append(temp)

            for child, c in graph[temp]:
                stack.append((cost + c, child))

ucs("A")