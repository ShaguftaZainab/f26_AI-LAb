
graph = {
   "S": [("A", 1), ("B", 4)],
    "A": [("C", 2)],
    "B": [("G", 5)],
    "C": [("G", 3)],
    "G": []
}

h = {
    "S": 5,
    "A": 4,
    "B": 4,
    "C": 10,
    "G": 0,
    
}

visited = []
stack = []

def astar(node):
    stack.append((h[node], 0, node))

    while stack:
        stack.sort()
        f, cost, temp = stack.pop(0)

        if temp not in visited:
            print(temp, "g:", cost, "h:", h[temp], "f:", f)
            visited.append(temp)

            if temp == "G":
                print("Goal Reached!")
                break

            for child, c in graph[temp]:
                new_cost = cost + c
                new_f = new_cost + h[child]
                stack.append((new_f, new_cost, child))

astar("A")