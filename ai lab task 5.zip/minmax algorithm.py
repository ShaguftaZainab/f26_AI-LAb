import math

scores = [1, 2, 3, 4, 5, 6, 7, 8,
          9, 10, 11, 12, 13, 14, 15, 16]

treeDepth = int(math.log2(len(scores)))

def minmax(currDepth, nodeIndex, isMaxTurn):
    if currDepth == treeDepth:
        return scores[nodeIndex]

    if isMaxTurn:
        return max(
            minmax(currDepth + 1, nodeIndex * 2, False),
            minmax(currDepth + 1, nodeIndex * 2 + 1, False)
        )
    else:
        return min(
            minmax(currDepth + 1, nodeIndex * 2, True),
            minmax(currDepth + 1, nodeIndex * 2 + 1, True)
        )

print(minmax(0, 0, True))