
class roomAgent:
    def __init__(self, desired_temp):
        self.d_t = desired_temp
        self.previous_mode = None

    def sensor(self, current_temp, occupied=True):
        self.c_t = current_temp
        self.occupied = occupied

    def act(self):
        if not self.occupied:
            target_mode = "ECO"
        elif self.c_t < 20:
            target_mode = "COOL"
        elif self.c_t > 26:
            target_mode = "WARM"
        else:
            target_mode = "IDLE"

        send_command = (target_mode != self.previous_mode)

        old_mode = self.previous_mode
        self.previous_mode = target_mode

        return old_mode, target_mode, send_command


rooms = [
    ("bedroom", 29, True),
    ("bedroom", 29, True),
    ("drawing room", 20, True),
    ("tv lounge", 26, True),
    ("store room", 19, True),
    ("store room", 29, False)
]

agent = roomAgent(16)

for step, (room, temp, occupied) in enumerate(rooms, 1):
    agent.sensor(temp, occupied)
    previous, target, send = agent.act()

    outcome = "SEND COMMAND" if send else "NO COMMAND"

    print(
        step, room, "temperature:", temp,
        "occupied:", occupied,
        "previous:", previous,
        "target:", target,
        "outcome:", outcome
    )
