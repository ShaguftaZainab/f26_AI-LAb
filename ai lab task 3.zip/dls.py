graph = {
    "A": ["B", "C"],
    "B": ["D", "E"],
    "C": ["F"],
    "D": [],
    "E": [],
    "F": ["G"],
    "G": []
}

def dls(node, goal, limit, path):
    if node == goal:
        return "FOUND", path

    # Check whether the depth limit has been reached
    if len(path) - 1 == limit:
        if any(child not in path for child in graph[node]):
            return "CUTOFF", []
        return "FAILURE", []

    cutoff_occurred = False

    for child in graph[node]:
        # Path-local cycle check
        if child not in path:
            status, result_path = dls(
                child, goal, limit, path + [child]
            )

            if status == "FOUND":
                return "FOUND", result_path

            if status == "CUTOFF":
                cutoff_occurred = True

    if cutoff_occurred:
        return "CUTOFF", []

    return "FAILURE", []


for limit in [1, 2, 3, 4]:
    status, path = dls("A", "G", limit, ["A"])

    print("Limit:", limit)
    print("Status:", status)
    print("Path:", path if status == "FOUND" else "Not found")
    print("--------------------")